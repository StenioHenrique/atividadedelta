<?php echo $this->include("menu_header", array("titulo" => $titulo)); ?>
<p><?php echo $msg ?></p>

<div class="col-sm-12">
    <div style="padding: 2%;">
        <h2><?= $titulo ?></h2>

        <table class="table table-hover table-bordered ">
            <thead>
                <tr>
                    <td>Nome </td>
                    <td>Endereco </td>
                    <td>Imagem</td>
                    <td></td>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alunos as $aluno) : ?>
                    <tr>
                        <td><?= $aluno->nome ?></td>
                        <td><?= $aluno->endereco ?></td>
                        <td><img width="50" height="50" src="<?= base_url('atividadedelta/' . $aluno->imgaluno) ?>" alt=""></td>
                        <td><a href="<?= base_url('atividadedelta/public/alunos/editar/' . $aluno->alunoid) ?>" class="btn btn-outline-primary" role="button" aria-pressed="true">Editar</a></td>
                        <td><button onclick="excluir(this.value)" value="<?= $aluno->alunoid ?>" class="btn btn-outline-danger" role="button">Excluir</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function excluir(alunoid) {
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
        })
        swalWithBootstrapButtons.fire({
            title: 'Tem certeza?',
            text: "",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sim, apague isso!',
            cancelButtonText: 'Não, cancele!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                $.post("alunos/excluir/" + alunoid, function(data) {
                    if (data == 'true') {
                        swalWithBootstrapButtons.fire(
                            'Apagado!'
                        )
                        window.location = "<?= base_url('atividadedelta/public/alunos') ?>"
                    } else {
                        swalWithBootstrapButtons.fire(
                            'Cancelado',
                            'Erro ao excluir aluno.'
                        )
                        window.location = "<?= base_url('atividadedelta/public/alunos') ?>"
                    }
                });
            } else if (result.dismiss === Swal.DismissReason.cancel) {
                swalWithBootstrapButtons.fire(
                    'Cancelado',
                    'Seu arquivo está seguro :)',
                    'error'
                )
            }
        })
    }
</script>

<?php echo $this->include("menu_footer"); ?>