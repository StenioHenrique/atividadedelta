<div id="footer">
    <p style="text-align: center;"> Atividade prática DELTA </p>
</div>

</body>
</html>