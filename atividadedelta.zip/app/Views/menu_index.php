<?php echo $this->include("menu_header", array("titulo" => $titulo)); ?>

<div class="col-sm-12">
    <div style="padding: 2%;">
        <h3 style="text-align: center;">Seja bem vindo! </h3>
        <hr>
    </div>
</div>

<?php echo $this->include("menu_footer"); ?>